Folder for data exports.
